
static int noneOfYourBusiness()
{
  return 42;
}

int main()
{
  noneOfYourBusiness();
  return 0;
}