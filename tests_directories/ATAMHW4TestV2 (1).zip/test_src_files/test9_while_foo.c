
int main()
{
  while(foo() < 20);
  return 0;
}