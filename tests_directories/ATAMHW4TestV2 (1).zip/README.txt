Instructions:
1. Unzip the provided zip file into a folder with your source files
2. chmod +x run_tests.sh
3. gcc -std=c99 *.c -o prf
4. ./run_tests.sh

If you think you've found a mistake in the tests, please contact me :)