
int func() {
    return 1;
}

int main() {
    int x=func();

    return 0;
}