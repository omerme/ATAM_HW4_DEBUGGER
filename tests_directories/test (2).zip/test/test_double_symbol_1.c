
static int func(int n) {
    return n*2;
}